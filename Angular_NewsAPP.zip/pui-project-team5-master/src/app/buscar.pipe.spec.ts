import { BuscarPipe } from './buscar.pipe';

describe('BuscarPipe', () => {
  it('create an instance', () => {
    const pipe = new BuscarPipe();
    expect(pipe).toBeTruthy();
  });
});
