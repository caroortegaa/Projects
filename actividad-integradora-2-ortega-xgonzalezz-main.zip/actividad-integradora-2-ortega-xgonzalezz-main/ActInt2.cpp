#include "prim.h"
#include "floyd-warshall.h"
#include "ford-fulkerson.h"
#include "closest_pair.h"
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

int main()
{
    ifstream archivo;
    string input;
    vector<string> contenidot;
    //por si el archivo no existe
    if (archivo.fail())
    {
        cout << "No se pudo acceder al archivo" << endl;
        exit(1);
    }

    archivo.open("input.txt");
    while (getline(archivo, input))
    {
        contenidot.push_back(input);
    }
    archivo.close();
    int n = stoi(contenidot[0]);
    /*for (int i = 0; i < contenidot.size(); i++)
    {
        cout << contenidot[i] << endl;
    }*/

    //prim PREGUNTA 1
    Grafo grafo_prim;
    for (int i = 0; i < n; i++)
    {
        grafo_prim.agregarNodo(to_string(i));
    }

    for (int i = 2; i < n + 2; i++)
    {
        string temp = "";
        int k = 0;
        for (int j = 0; j < contenidot[i].length(); j++)
        {
            if (contenidot[i][j] == ' ')
            {

                grafo_prim.agregarAdyacenciaNoDirigida(to_string(i - 2), to_string(k), stoi(temp));
                temp = "";
                k++;
            }
            else
            {
                temp.push_back(contenidot[i][j]);
            }
        }
        grafo_prim.agregarAdyacenciaNoDirigida(to_string(i - 2), to_string(k), stoi(temp));
    }

    //Grafo minimo = grafo_prim.MST();

    //floyd_warshall PREGUNTA 2
    int **matriz_distancias;
    int **matriz_next;
    matriz_distancias = new int *[n];

    //for para crear matrices
    for (int i = 0; i < n; i++)
    {
        matriz_distancias[i] = new int[n];
    }

    matriz_next = new int *[n];
    for (int i = 0; i < n; i++)
    {
        matriz_next[i] = new int[n];
    }

    for (int i = 0; i < n; i++)
    {

        for (int j = 0; j < n; j++)
        {
            if (i == j)
            {
                matriz_distancias[i][j] = 0;
                matriz_next[j][j] = j;
            }
            else
            {
                matriz_distancias[i][j] = INF;
                matriz_next[i][j] = -1;
            }
        }
    }
    for (int p = 0; p < n; p++)
    {
        matriz_distancias[p][p] = 0;
    }

    int nodo_inicial_bus = 0;
    int nodo_final_bus = n - 1;
    int nodo1;
    int nodo2;
    int peso;

    for (int i = 2; i < n + 2; i++)
    {
        string temp = "";
        int k = 0;

        for (int j = 0; j < contenidot[i].length(); j++)
        {
            if (contenidot[i][j] == ' ')
            {
                nodo1 = i - 2;
                nodo2 = k;
                peso = stoi(temp);
                temp = "";
                k++;
                LlenarMatriz(nodo1, nodo2, peso, matriz_distancias, matriz_next);
            }
            else
            {
                temp.push_back(contenidot[i][j]);
            }
        }
        nodo2 = k;
        peso = stoi(temp);
        LlenarMatriz(nodo1, nodo2, peso, matriz_distancias, matriz_next);
    }
    /*for (int i=0; i < n ; i++)
    {
        for (int j=0; j< n ; j++)
        {
            cout << matriz_distancias[i][j] << " ";
        }
        cout << endl;
    }*/
    FW(n, matriz_distancias, matriz_next, nodo_inicial_bus, nodo_final_bus);

    //ford.fulkerson

    int **matriz_distancias2;
    matriz_distancias2 = new int *[n];

    //for para crear matrices
    for (int i = 0; i < n; i++)
    {
        matriz_distancias2[i] = new int[n];
    }

    for (int i = 0; i < n; i++)
    {

        for (int j = 0; j < n; j++)
        {
            if (i == j)
            {
                matriz_distancias2[i][j] = 0;
            }
            else
            {
                matriz_distancias2[i][j] = 0;
            }
        }
    }

    for (int p = 0; p < n; p++)
    {
        matriz_distancias2[p][p] = 0;
    }

    for (int i = 3; i < n + 3; i++)
    {
        string temp = "";
        int k = 0;

        for (int j = 0; j < contenidot[i + n].size(); j++)
        {
            if (contenidot[i + n][j] == ' ')
            {
                nodo1 = i - 3;
                nodo2 = k;
                peso = stoi(temp);
                temp = "";
                k++;
                LlenarMatriz(nodo1, nodo2, peso, matriz_distancias2);
            }
            else
            {
                temp.push_back(contenidot[i + n][j]);
            }
        }
        nodo2 = k;
        peso = stoi(temp);
        LlenarMatriz(nodo1, nodo2, peso, matriz_distancias2);
    }

    cout << FF(nodo_inicial_bus, nodo_final_bus, n, matriz_distancias2) << endl;

    //closest pair
    vector<Point> points;
    /*for (int i = 4; i < n + 4; i++)
    {
        points.push_back(Point(stoi(contenidot[i + (n * 2)]), stoi(contenidot[i + (n * 3)])));
    }*/
    for (int i = 4; i < n + 4; i++)
    {
        string temp = "";
        string temp_x = "";
        string temp_y = "";
        cout << contenidot[i + (n * 2)] << endl;

        for (int j = 0; j < contenidot[i + n * 2].size(); j++)
        {
            //cout << contenidot[i + (n * 2)] << endl;
            if (contenidot[i + n * 2][j] == ')') //contenidot[i + n * 2][j] == ',' ||
            {
                temp_y = temp;
                points.push_back(Point(stoi(temp_x), stoi(temp_y)));
                temp = "";
                temp_x = "";
                temp_y = "";
            }
            else if (contenidot[i + (n * 2)][j] == ',')
            {
                temp_x = temp;
                temp = "";
            }
            else if (contenidot[i + (n * 2)][j] != '(')
            {
                temp.push_back(contenidot[i + (n * 2)][j]);
                //cout << "TEMP: " << temp << endl;
            }
            else if (contenidot[i + (n * 2)][j] != ' ')
            {
                continue;
            }

        }
        //cout << "I: " << i << endl;
        //points.push_back(Point(stoi(temp), stoi(temp)));
        
    }
    cout << "end for completo ";
    cout << "The smallest distance is " << closest(points, n);
    /*for (int i = 4; i < n + 4; i++)
    {
        cout << contenidot[i + (n * 2)] << endl;
    }*/
}
