#include <iostream>
#include <vector>
#define INF 99999

using namespace std;

void LlenarMatriz(int nodo1, int nodo2, int peso, int **matriz_distancias, int **matriz_next)
{
    matriz_distancias[nodo1][nodo2] = peso;
    matriz_next[nodo1][nodo2] = nodo2;
}

void FW(int vertices, int **matriz_distancias, int **matriz_next, int nodo_inicial_bus, int nodo_final_bus)
{

    int **matriz_final = matriz_distancias;

    for (int k = 0; k < vertices; k++)
    {
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                if (matriz_final[i][j] > (matriz_final[i][k] + matriz_final[k][j]))
                {
                    matriz_final[i][j] = (matriz_final[i][k] + matriz_final[k][j]);
                    matriz_next[i][j] = matriz_next[i][k];
                }
            }
        }
    }

    while (nodo_inicial_bus != nodo_final_bus)
    {
        int next = matriz_next[nodo_inicial_bus][nodo_final_bus];
        cout << nodo_inicial_bus << " " << next << " " << matriz_distancias[nodo_inicial_bus][next] << endl;

        nodo_inicial_bus = next;
    }
}
/*
int main(int argc, char const *argv[])
{
    int vertices = stoi(argv[1]);
    int **matriz_distancias;
    int **matriz_next;
    matriz_distancias = new int *[vertices];
    //for para crear matrices
    for (int i = 0; i < vertices; i++)
    {
        matriz_distancias[i] = new int[vertices];
    }

    matriz_next = new int *[vertices];
    for (int i = 0; i < vertices; i++)
    {
        matriz_next[i] = new int[vertices];
    }

    for (int i = 0; i < vertices; i++)
    {

        for (int j = 0; j < vertices; j++)
        {
            if (i == j)
            {
                matriz_distancias[i][j] = 0;
                matriz_next[j][j] = j;
            }
            else
            {
                matriz_distancias[i][j] = INF;
                matriz_next[i][j] = -1;
            }
        }
    }
    for (int p = 0; p < vertices; p++)
    {
        matriz_distancias[p][p] = 0;
    }

    int nodo_inicial_bus = stoi(argv[vertices * 3 + 2]);
    int nodo_final_bus = stoi(argv[vertices * 3 + 3]);

    for (int i = 0; i < vertices; i++)
    {
        int nodo1 = stoi(argv[i + 2]);
        int nodo2 = stoi(argv[i + vertices + 2]);
        int peso = stoi(argv[vertices * 2 + i + 2]);
        LlenarMatriz(nodo1, nodo2, peso, matriz_distancias, matriz_next);
    }

    FW(vertices, matriz_distancias, matriz_next, nodo_inicial_bus, nodo_final_bus);
}*/