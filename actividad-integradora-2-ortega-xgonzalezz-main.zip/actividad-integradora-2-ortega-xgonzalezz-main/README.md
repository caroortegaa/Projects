[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-f059dc9a6f8d3a56e377f745f24479a46679e63a5d9fe6f495e02850cd0d8118.svg)](https://classroom.github.com/online_ide?assignment_repo_id=6382361&assignment_repo_type=AssignmentRepo)
# Actividad Integradora 2

## Propósito
El propósito de esta actividad integradora, es que, como su nombre lo indica, integres todos los contenidos revisados desde la presentación de la [Actividad Integradora anterior](https://experiencia21.tec.mx/courses/173572/assignments/4688194?module_item_id=8145207), hasta el momento, en esta unidad de formación para proponer una solución a la [Situación Problema 2](https://experiencia21.tec.mx/courses/173572/pages/situacion-problema-2?module_item_id=8145346)

## ¿Qué niveles de dominio de subcompetencias voy a demostrar con esta evidencia?

SICT0101C - Explica el funcionamiento de sistemas computacionales por medio de argumentaciones sustentadas en las interacciones entre los componentes y su entorno creando modelos conceptuales donde se describan los componentes y la relación con su entorno.

SICT0401C - Aplica los estándares y normas propios de su profesión contrastándolos contra las restricciones de uso de acuerdo al proceso, producto o servicio donde se va a aplicar usando las normas y estándares más relevantes al dominio del problema que se va a resolver, distinguiendo claramente entre ambos.

STC0101B - Implementa algoritmos computacionales confiables y correctos que solucionan problemas

STC0102B - Optimiza algoritmos computacionales robustos y eficientes que se aplican en el desarrollo de soluciones

## ¿Qué tengo que hacer?
En equipos de máximo 3 personas,

Escribe en C++ un programa que ayude a una empresa que quiere incursionar en los servicios de Internet respondiendo a la situación problema 2.

El programa debe:

1. leer un archivo de entrada que contiene la información de un grafo representado en forma de una matriz de adyacencias con grafos ponderados
El peso de cada arista es la distancia en kilómetros entre colonia y colonia, por donde es factible meter cableado.

El programa debe desplegar cuál es la forma óptima de cablear con fibra óptica conectando colonias de tal forma que se pueda compartir información entre cuales quiera dos colonias.

2. Debido a que las ciudades apenas están entrando al mundo tecnológico, se requiere que alguien visite cada colonia para ir a dejar estados de cuenta físicos, publicidad, avisos y notificaciones impresos. Por eso se quiere saber ¿cuál es la ruta más corta posible entre dos colonias dadas (una colonia origen y una destino)?
El programa debe desplegar la ruta a considerar, tomando en cuenta que debe mostrar las colonias en el orden en que son visitadas para llegar del origen al destino.

3. El programa también debe leer otra matriz cuadrada de N x N datos que representen la capacidad máxima de transmisión de datos entre la colonia i y la colonia j. Como estamos trabajando con ciudades con una gran cantidad de campos electromagnéticos, que pueden generar interferencia, ya se hicieron estimaciones que están reflejadas en esta matriz.

La empresa quiere conocer el flujo máximo de información del nodo inicial al nodo final. Esto debe desplegarse también en la salida estándar.

Por último

4. Teniendo en cuenta la ubicación geográfica de varias "centrales", (donde no necesariamente hay una central por cada colonia y se pueden tener colonias sin central, y colonias con más de una central) la empresa quiere contar con una forma de conocer cuales son las dos centrales más cercanas entre sí. 

**Entrada:**
Un numero entero N que representa el número de colonias en la ciudad
matriz cuadrada de N x N que representa el grafo con las distancias en kilómetros entre las colonias de la ciudad
matriz cuadrada de N x N que representa las capacidades máximas de flujo de datos entre colonia i y colonia j
lista de N pares ordenados de la forma (A,B) que representan la ubicación en un plano coordenado de las centrales

**Salida:**
1. forma de cablear las colonias con fibra (lista de arcos de la forma (A,B))
2. ruta a seguir por el personal que reparte correspondencia, considerando origen y destino.
3. valor de flujo máximo de información del nodo inicial al nodo final
4. coordenadas de las dos centrales más cercanas entre sí


Ejemplo de entrada:
```
4

0 16 45 32
16 0 18 21
45 18 0 7
32 21 7 0

0 48 12 18
52 0 42 32
18 46 0 56
24 36 52 0

(200,500)
(300,100)
(450,150)
(520,480)
```
Salida:
```
(0, 1)
(1, 2)
(2, 3)

0 3

78

(300, 100)
(450, 150)
```
*Nota*:
- En todos los casos el nodo inicial será el 0 y el nodo final será el N-1
- La entrada para el programa estará en el archivo input.txt

## ¿Bajo qué criterios se evalúa mi evidencia?

Para obtener el 100% de los puntos de esta actividad, tu programa:

- **80%** - Cumple correcta y eficientemente con la funcionalidad requerida por parte de la actividad:
  - **20%** primera parte del output (forma de cableado óptimo).
  - **20%** - segunda parte del output (ruta para repartir correspondencia)
  - **20%** - tercera parte del output (flujo máximo de información)
  - **20%** - cuarta parte del output (lista de polígonos)
- **15%** - El documento de reflexión incluye la explicación de diferentes algoritmos aplicados a esta situación problema, así como la complejidad computacional de cada uno de ellas.
- **05%** - El código deberá seguir los lineamientos estipulados en el estándar de codificación  [descargar](https://experiencia21.tec.mx/courses/173572/files/52881961?wrap=1)

### ¿Dónde la entrego?
En este espacio en GitHub classroom. En la pestaña de "Actions" se evaluará el código con los casos de prueba. 

También se deberá subir el código al [espacio de la actividad en Canvas](https://experiencia21.tec.mx/courses/173572/assignments/4688206). 
Esta actividad forma parte tanto de tu calificación final del curso, así como del portafolio de evidencias de las competencias a desarrollar del curso, por lo que se te pide que :
* Realices una entrega de  los archivos correspondientes a la solución a esta actividad en equipo dentro del espacio de Canvas, que contenga los documentos de reflexión individual (ReflexActInt2.pdf ).
* Generes una carpeta en forma personal INDIVIDUAL llamada TC2038(Portafolio_Final), agrega los archivos correspondientes a esta actividad en la carpeta "ActInt2":
  - ActInt1 - 
  - ActInt2 - coloca aquí tus archivos que solucionaron la actividad integradora 2 así como el documento de reflexión individual (ReflexActInt2.pdf).

Esta  carpeta (TC2038(Portafolio_Final))es la que subirás al final de la Unidad de Formación en el espacio que se habilitará para tu portafolio de evidencias en eLumen

### ¿Cómo la entrego?
Se tomarán en cuenta las soluciones sometidas en este repositorio de la plataforma de GitHub classroom. Pueden subir su archivo "ActInt2.cpp" por separado o editar el que está arriba y someterlo via *commit*.

Adicionalmente, en el espacio de la tarea en canvas, entrega un archivo .ZIP llamado A0XXXXXXX_ActInt2, (donde las XXXXXXXs son la matrícula de alguno de los integrantes del equipo) que contenga dentro una carpeta llamada A0XXXXXXX_ActInt2, en donde se encontrará UN único archivo .cpp. Se pueden tener uno o más archivos .h.
Incluye un archivo team.txt que incluya los nombres de todos los integrantes del equipo, con sus matrículas y las partes específicas del proyecto en las que trabajó cada quien
Incluye también los 3 archivos ReflexActInt2_A0XXXXXXX.pdf

Ten en cuenta que tu programa se probará con casos de prueba grandes.

Se tendrá una sesión de revisión donde a cada integrante del equipo se le harán preguntas específicas y todos deben saber cómo funciona cada parte de la solución propuesta
