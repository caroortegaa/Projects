//Ximena Gonzalez A01028604
//Carolina Ortega A01025254
//Ford-fulkerson maximum flow
//Fecha de entrega: Miércoles 10 de noviembre 2021
//Profesor:Leonardo Chang

#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#define INF 99999

using namespace std;

void LlenarMatriz(int nodo1, int nodo2, int peso, int **matriz_distancias)
{
    matriz_distancias[nodo1][nodo2] = peso;
}

//Función bfs para revisar los elementos visitados y encontrar caminos
bool bfs(int vertices, int **matriz_distancias, int s, int t, int parent[])
{
    bool visited[vertices]; //arreglo de true false
    memset(visited, 0, sizeof(visited));

    queue<int> q; //lista de los caminos
    q.push(s);
    visited[s] = true;
    parent[s] = -1; //como se empieza en s, no hay padre

    //mientras haya algo...
    while (!q.empty())
    {
        int u = q.front();
        //borrar el primer elemento para que s avance
        q.pop();

        for (int v = 0; v < vertices; v++)
        {
            //para indicar que ese nodo ya fue visitado y que se encuentre otro camino
            if (visited[v] == false && matriz_distancias[u][v] > 0)
            {
                q.push(v);
                parent[v] = u;
                visited[v] = true;
            }
        }
    }

    return (visited[t] == true);
}

//Algoritmo
int FF(int s, int t, int vertices, int **matriz_distancias)
{
    int **matriz_flujo = matriz_distancias;
    int max_flow = 0;
    int parent[vertices];

    //mientras haya caminos no visitados
    while (bfs(vertices, matriz_flujo, s, t, parent))
    {
        int camino = INF;
        //para encontrar el cuello de botella
        for (int v = t; v != s; v = parent[v])
        {
            int u = parent[v];
            camino = min(camino, matriz_flujo[u][v]);
        }

        for (int v = t; v != s; v = parent[v])
        {
            int u = parent[v];
            matriz_flujo[u][v] -= camino; //IDA
            matriz_flujo[v][u] += camino; //REGRESO
        }
        max_flow += camino;
    }
    return max_flow;
}
/*
int main(int argc, char const *argv[])
{
    int vertices = stoi(argv[1]);
    int **matriz_distancias;
    matriz_distancias = new int *[vertices];

    //for para crear matrices
    for (int i = 0; i < vertices; i++)
    {
        matriz_distancias[i] = new int[vertices];
    }

    for (int i = 0; i < vertices; i++)
    {

        for (int j = 0; j < vertices; j++)
        {
            if (i == j)
            {
                matriz_distancias[i][j] = 0;
            }
            else
            {
                matriz_distancias[i][j] = 0;
            }
        }
    }
    for (int p = 0; p < vertices; p++)
    {
        matriz_distancias[p][p] = 0;
    }

    int nodo_inicial_bus = stoi(argv[vertices * 3 + 2]);
    int nodo_final_bus = stoi(argv[vertices * 3 + 3]);

    for (int i = 0; i < vertices; i++)
    {
        int nodo1 = stoi(argv[i + 2]);
        int nodo2 = stoi(argv[i + vertices + 2]);
        int peso = stoi(argv[vertices * 2 + i + 2]);
        LlenarMatriz(nodo1, nodo2, peso, matriz_distancias);
    }

    //llamar a ford-fulkerson e imprimir el resultado
    cout << FF(nodo_inicial_bus, nodo_final_bus, vertices, matriz_distancias) << endl;
}*/