//CLOSEST PAIR
//Ximena Gonzalez , Carolina Ortega

#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <cfloat>
using namespace std;

struct Point
{
    int x, y;
    Point(int x_, int y_)
    {
        x = x_;
        y = y_;
    }
    Point(){};
};

int compareX(Point &a, Point &b)
{
    return a.x < b.x;
}

int compareY(Point &a, Point &b)
{
    return a.y < b.y;
}

//da la distancia entre los puntos
float dist(Point p1, Point p2)
{
    return sqrt((p1.x - p2.x) * (p1.x - p2.x) +
                (p1.y - p2.y) * (p1.y - p2.y));
}

//recibe dos puntos y llama a dist para sacar dist minima
float bruteForce(vector<Point> points, int n)
{
    float min = FLT_MAX;
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (dist(points[i], points[j]) < min)
                min = dist(points[i], points[j]);
    return min;
}

float min(float x, float y)
{
    return (x < y) ? x : y;
}

//revisa si hay una menor distancia en el strip 
float stripClosest(vector<Point> strip, int size, float d)
{
    float min = d; 

    sort(strip.begin(), strip.end(), compareY);

    for (int i = 0; i < size; ++i)
        for (int j = i + 1; j < size && (strip[j].y - strip[i].y) < min; ++j)
            if (dist(strip[i], strip[j]) < min)
                min = dist(strip[i], strip[j]);

    return min;
}

//llamada recursiva para dividir en dos vectores el vector principal
float closestUtil(vector<Point> points, int n)
{
    if (n <= 3)
        return bruteForce(points, n);

    // Find the middle point
    int mid = n / 2;
    Point midPoint = points[mid];

    float dl = closestUtil(vector<Point>(points.begin(), points.begin() + mid), mid); //desde begin hasta begin + mid
    float dr = closestUtil(vector<Point>(points.begin() + mid, points.end()), n - mid); //desde mitad al final

    float d = min(dl, dr);

    //crear el vector del strip 
    vector<Point> strip;
    int j = 0;
    for (int i = 0; i < n; i++)
        if (abs(points[i].x - midPoint.x) < d)
            strip[j] = points[i], j++;

    return min(d, stripClosest(strip, j, d));
}

//ordena el vector dependiendo de "y" y llama a la funcion para empezar lo recursivo
float closest(vector<Point> points, int n)
{
    sort(points.begin(), points.end(), compareX);

    return closestUtil(points, n);
}

/*int main(int argc, char *argv[])
{

    int n = stoi(argv[1]);
    vector<Point> points;
    //vector<Point> strip;
    for (int i = 2; i < n + 2; i++)
    {
        points.push_back(Point(stoi(argv[i]), stoi(argv[i + n])));
    }

    cout << "The smallest distance is " << closest(points, n);

    return 0;
}*/