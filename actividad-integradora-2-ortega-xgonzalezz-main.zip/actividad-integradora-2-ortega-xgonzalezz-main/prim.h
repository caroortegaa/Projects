#include <iostream>
#include <unordered_map>
#include <vector>
#include <functional>
#include <queue>
#include <unordered_set>
#include <stack>

using namespace std;

using par_nodos = pair<string, string>;
using conjunto = pair<int, par_nodos>;

class Nodo
{
public:
    string nombre;
    unordered_map<Nodo *, int> siguientes;
    bool visitado;

    Nodo()
    {
        nombre = "";
        visitado = false;
    }

    Nodo(string n)
    {
        nombre = n;
        visitado = false;
    }

    void agregarSiguiente(Nodo *sig, int peso)
    {
        siguientes[sig] = peso;
    }

    
    void imprimirNodo()
    {
        for (auto sig : siguientes)
        {
            sig.first->nombre, sig.second;
        }
    }
};

class Grafo
{
public:
    unordered_map<string, Nodo *> nodos;

    void agregarNodo(string n)
    {
        Nodo *nuevo = new Nodo(n);
        if (nodos.find(n) == nodos.end())
        {
            nodos[n] = nuevo;
        }
    }

    void agregarAdyacencia(string n1, string n2, int peso)
    {
        nodos[n1]->agregarSiguiente(nodos[n2], peso);
    }

    void agregarAdyacenciaNoDirigida(string n1, string n2, int peso)
    {
        nodos[n1]->agregarSiguiente(nodos[n2], peso);
        nodos[n2]->agregarSiguiente(nodos[n1], peso);
    }

    void imprimirGrafo()
    {
        for (auto nodo : nodos)
        {
            nodo.second->imprimirNodo();
        }
    }

    void DFS(string inicial)
    {
        for (auto nodo : nodos)
        {
            nodo.second->visitado = false;
        }
        stack<Nodo *> porProcesar;
        porProcesar.push(nodos[inicial]);
        while (!porProcesar.empty())
        {
            Nodo *nodos_check = porProcesar.top();
            porProcesar.pop();
            for (auto sig : nodos_check->siguientes)
            {
                if (!sig.first->visitado)
                {
                    porProcesar.push(sig.first);
                }
            }
            nodos_check->visitado = true;
        }
        
    }

    Grafo MST()
    {
        Grafo g;
        int V = nodos.size();
        unordered_set<string> enlance;
        priority_queue<conjunto, vector<conjunto>, greater<conjunto> > aristas;
        unordered_map<string, string> nodo_padre;
        
        for (auto nodo : nodos)
        {
            for (auto sig : nodo.second->siguientes)
            {
                aristas.push(conjunto(sig.second, par_nodos(nodo.first, sig.first->nombre)));
            }
            nodo_padre[nodo.first] = nodo.first;
        }
        
        while (enlance.size() < V - 1 && !aristas.empty())
        {
            conjunto nodos_check = aristas.top();
            aristas.pop();
            string nodo_principio = nodos_check.second.first; 
            string nodo_final = nodos_check.second.second;    
            if (nodo_principio > nodo_final)
            {
                string temp = nodo_principio;
                nodo_principio = nodo_final;
                nodo_final = temp;
            }
            string x = buscar(nodo_padre, nodo_principio);
            string y = buscar(nodo_padre, nodo_final);
            if (x != y && enlance.find(nodo_principio + nodo_final) == enlance.end())
            {
                g.agregarNodo(nodo_principio);
                g.agregarNodo(nodo_final);
                g.agregarAdyacenciaNoDirigida(nodo_principio, nodo_final, nodos_check.first);
                unir(nodo_padre, nodo_principio, nodo_final);
                cout << nodo_final << " " << nodo_principio << " " << nodos_check.first << endl;
                
                enlance.insert(nodo_principio + nodo_final);
            }
        }
        return g;
    }

    string buscar(unordered_map<string, string> nodo_padre, string buscado)
    {
        if (nodo_padre[buscado] == buscado)
        {
            return buscado;
        }
        return buscar(nodo_padre, nodo_padre[buscado]);
    }

    void unir(unordered_map<string, string> &nodo_padre, string nodo_principio, string nodo_final)
    {
        nodo_padre[nodo_final] = buscar(nodo_padre, nodo_principio);
        nodo_padre[nodo_principio] = buscar(nodo_padre, nodo_final);
    }
};

/*int main(int argc, char const *argv[])
{
    Grafo g;
    int nodos = stoi(argv[1]);
    for (int i = 0; i < nodos; i++)
    {
        g.agregarNodo(to_string(i));
    }

    for (int i = 0; i < nodos; i++)
    {
        int siguiente = stoi(argv[i + 2 + nodos * 2]);
        if (siguiente != 0)
        {
            g.agregarAdyacenciaNoDirigida(to_string(stoi(argv[i + 2])), to_string(stoi(argv[i + 2 + nodos])), siguiente);
        }
    }

    Grafo minimo = g.MST();
    minimo.imprimirGrafo();
    return 0;
}*/