#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <fstream>
#include <vector>
#define MAX 1000

using namespace std;

vector<string> leerDatos(string path)
{
    ifstream archivo(path);
    string texto;
    vector<string> contenido;

    //por si el archivo no existe
    if (archivo.fail())
    {
        cout << "No se pudo acceder al archivo" << endl;
        exit(1);
    }

    //función eof (librería de fstream) recorre todo el archivo y envia true o false
    //mientras no sea el final, recorre todo el acrhivo
    while (getline(archivo, texto))
    {
        contenido.push_back(texto);
    }

    return contenido;
    //archivo.close(); //cerramos el archivo
}

int bad_character(string cadena, string palabra, int l, int salto, int i)
{
    salto = 0;

    for (int j = i - 1; j <= palabra.size() && j != -1; j--)
    {
        if (cadena[l] == palabra[j])
        {
            salto = palabra.length() - (j + 1);
            break;
        }
    }
    if (salto == 0)
    {

        salto = palabra.length();
    }
    return salto;
}

int min(int num1, int num2)
{
    int result;
    if (num1 > num2)
    {
        result = num2;
    }
    else
    {
        result = num1;
    }

    return result;
}

int palindromo(string palabra)
{
    int l = palabra.length() - 1;
    int c = 1; //centro de la palabra
    int d = 1; //limite de la derecha
    vector<int> tamaño(l, 0);
    cout << "palindromo" << endl;

    for (int i = 1; i <= l - 1; i++)
    {
        int mirror = 2 * c - i;
        cout << "MIRROR: " << mirror << endl;

        if (i < d)
        {
            tamaño[i] = min(d - i, tamaño[mirror]);
            cout << "TAMAÑO[I] if 1: " << tamaño[i] << endl;
        }
        else
        {
            tamaño[i] = 0;
            cout << "TAMAÑO[I] else 1: " << tamaño[i] << endl;
        }

        int a = palabra[i + (1 + tamaño[i])];
        cout << "A: " << a << endl;
        int b = palabra[i - (1 + tamaño[i])];
        cout << "B: " << b << endl;

        while (a == b)
        {
            a = palabra[i + (1 + tamaño[i])];
            b = palabra[i - (1 + tamaño[i])];
            tamaño[i]++;
            cout << "IGUALES: " << endl;
            cout << "A: " << a << endl;
            cout << "B: " << b << endl;
        }

        if (i + tamaño[i] > d)
        {
            c = i;
            d = i + tamaño[i];
            cout << "IF 2 " << tamaño[i] << endl;
        }
    }
    return c;
}

int lcs(string s1, string s2)
{
    int mat[MAX][MAX];
    int max = 0;
    for (int i = 0; i < s1.length(); i++)
    {
        if (s1[i] == s2[0])
        {
            mat[i][0] = 1;
            max = 1;
        }
        else
        {
            mat[i][0] = 0;
        }
    }
    for (int j = 0; j < s2.length(); j++)
    {
        if (s1[0] == s2[j])
        {
            mat[0][j] = 1;
            max = 1;
        }
        else
        {
            mat[0][j] = 0;
        }
    }
    for (int i = 1; i < s1.length(); i++)
    {
        for (int j = 1; j < s2.length(); j++)
        {
            if (s1[i] == s2[j])
            {
                mat[i][j] = mat[i - 1][j - 1] + 1;
                if (mat[i][j] > max)
                {
                    max = mat[i][j];
                }
            }
            else
            {
                mat[i][j] = 0;
            }
        }
    }
    return max;
}

int main(int argc, char *argv[])
{
    //leer datos
    vector<string> mcode;
    lectura(); //llamar a función
    vector<string> trans1 = leerDatos("transmission1.txt");
    vector<string> trans2 = leerDatos("transmission2.txt");
    vector<string> mcode1 = leerDatos("mcode1.txt");
    vector<string> mcode2 = leerDatos("mcode2.txt");
    vector<string> mcode3 = leerDatos("mcode3.txt");

    mcode.push_back(mcode1[0]);
    mcode.push_back(mcode2[0]);
    mcode.push_back(mcode3[0]);

    trans.push_back(trans1[0]);
    trans.push_back(trans2[0]);

    set<int> r;

    for (int i = 0; i < trans.size(); i++)
    {
        for (int j = 0; j < mcode.size(); j++)
        {
            r = bad_character(trans[i], mcode[j])
        }
    }

    //palindromo
    //string palabra= "HOLA";
    string palabra_nueva;
    set<int> p;
    int j = 0;
    for (int i = 0; i < trans.size(); i++)
    {
        for (int j = 0; j < mcode.size(); j++)
        {
            p = trans[i], mcode[j];
            for (int i = 0; i < p.length() * 2 + 1; i++)
            {
                if (i % 2 == 0)
                {
                    palabra_nueva.push_back('#');
                }
                if (i % 2 != 0)
                {
                    palabra_nueva.push_back(p[j]);
                    j++;
                }
            }
            palindromo(palabra_nueva)
        }
    }

        //parte 3
    int nCases = stoi(argv[3]);
    string s1 = argv[1];
    string s2 = argv[2];

    for (int i = 1; i <= nCases; i++)
    {
        cout << i << ": " << lcs(s1, s2) << endl;
    }
}
