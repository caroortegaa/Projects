[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-f059dc9a6f8d3a56e377f745f24479a46679e63a5d9fe6f495e02850cd0d8118.svg)](https://classroom.github.com/online_ide?assignment_repo_id=450248&assignment_repo_type=GroupAssignmentRepo)
# Actividad Integradora 1

## Propósito
El propósito de esta actividad integradora, es que, como su nombre lo indica, integres todos los contenidos revisados hasta el momento en esta unidad de formación para proponer una solución a la [Situación Problema 1](https://experiencia21.tec.mx/courses/173572/pages/situacion-problema-1-2)

## ¿Qué niveles de dominio de subcompetencias voy a demostrar con esta evidencia?

SICT0101C - Explica el funcionamiento de sistemas computacionales por medio de argumentaciones sustentadas en las interacciones entre los componentes y su entorno creando modelos conceptuales donde se describan los componentes y la relación con su entorno.

SICT0401C - Aplica los estándares y normas propios de su profesión contrastándolos contra las restricciones de uso de acuerdo al proceso, producto o servicio donde se va a aplicar usando las normas y estándares más relevantes al dominio del problema que se va a resolver, distinguiendo claramente entre ambos.

STC0101B - Implementa algoritmos computacionales confiables y correctos que solucionan problemas

STC0102B - Optimiza algoritmos computacionales robustos y eficientes que se aplican en el desarrollo de soluciones

## ¿Qué tengo que hacer?
En equipos de máximo 3 personas, escribe un programa en C++ que lea 5 archivos de texto (de nombre fijo, no se piden al usuario) que contienen exclusivamente caracteres del 0 al 9, caracteres entre A y F y saltos de línea

```
     transmission1.txt 
     transmission2.txt 
     mcode1.txt 
     mcode2.txt 
     mcode3.txt
 ```
Los archivos de transmisión contienen caracteres de texto que representan el envío de datos de un dispositivo a otro. El archivo puede contener varias líneas, donde cada línea es una transmisión.

Los archivos mcodeX.txt representan código malicioso que se puede encontrar dentro de una transmisión.

En el siguiente enlace ([hacer clic aquí](https://drive.google.com/drive/folders/18AXOKc3Ej1AGA2R4I8Ley-VihjCtTe5Z?usp=sharing)) podrán encontrar 3 juegos de datos de diferentes tamaños. Para la evaluación, se utilizarán datos diferentes a estos y de tamaños similares a los small y medium. Por tanto, vuestros programas no deben solo funcionar con estos ficheros, sino con cualquier juego de datos de igual estructura.

## ¿Qué debe regresar mi programa?

### Parte 1
El programa debe analizar si el contenido de los archivos mcode1.txt, mcode2.txt y mcode3.,txt están contenidos en los archivos transmission1.txt y transmission2.txt y desplegar un true o false si es que las secuencias de chars están contenidas o no. En caso de ser true, muestra true, seguido de exactamente un espacio, seguido de la línea y columna (posición) en el archivo de transmissiónX.txt donde inicia el código de mcodeY.txt.

### Parte 2
Suponiendo que el código malicioso tiene siempre código "espejeado" (palíndromos de chars), sería buena idea buscar este tipo de código en una transmisión. El programa después debe buscar si hay código "espejeado" dentro de los archivos de transmisión (palíndromo a nivel chars, no meterse a nivel bits). El programa muestra en una sola línea tres enteros separados por un espacio correspondientes a la línea, posición inicial y tamaño, respectivamente, correspondiente al código "espejeado" más largo (palíndromo) para cada archivo de transmisión. Puede asumirse que siempre se encontrará este tipo de código.

### Parte 3
Finalmente el programa analiza qué tan similares son los archivos de transmisión, y debe mostrar la línea, la posición inicial y tamaño en el primer archivo en donde se encuentra el substring más largo común entre ambos archivos de transmisión.

_*Notas*_: 

* En todo caso se asumen índices que comienzan en cero (no en uno)
* las respuestas deben mostrarse en orden de aparición (ascendentemente) y 
* respecto al archivo original

## Ejemplo de entrada y salida
Seguido un ejemplo de ejecución del programa. Nótese que no se le pasa ningún argumento al programa, se asume que los 5 ficheros mencionados tienen exactamente esos nombres y se encuentran en la misma carpeta del archivo ejecutable.

```
>> ./a.out  
true 4 34
false
true  21 1345
true  16 15
true  0 532
true  221 0

547 32 2435
67 128 34

11 98 1381
```
_*Notas*_: 

* Las tres primeras líneas corresponden a las apariciones del contenido de los ficheros mcode1.txt, mcode2.txt y mcode3.txt, respectivamente, en el fichero tranmission1.txt. 
* El segundo grupo de tres líneas corresponden a las apariciones del contenido de los ficheros mcode1.txt, mcode2.txt y mcode3.txt, respectivamente, en el fichero tranmission2.txt. 
* Las respuestas de la parte 1, parte 2 y parte 3, van separadas entre sí por un cambio de línea.
* Respecto a la salida esperada. Tomen en cuenta que la respuesta debe tener exactamente el mismo formato para que pueda ser evaluado automáticamente por el auto grader de Github Classroom.

## ¿Bajo qué criterios se evalúa mi evidencia?

Para obtener el 100% de los puntos de esta actividad, tu programa:

- **75%** - Cumple correcta y eficientemente con la funcionalidad requerida por parte de la actividad:
  - **25%** primera parte del output (búsqueda de subsecuencias).
  - **25%** - segunda parte del output (palíndromos en las secuencias de transmisión)
  - **25%** - tercera parte del output (substring más largo común)
- **20%** - El documento de reflexión incluye la explicación de diferentes algoritmos aplicados a esta situación problema, así como la complejidad computacional de cada uno de ellas.
- **05%** - El código deberá seguir los lineamientos estipulados en el estándar de codificación  [descargar](https://experiencia21.tec.mx/courses/173572/files/52881961?wrap=1)

### ¿Dónde la entrego?
En este espacio en GitHub classroom. En la pestaña de "Actions" se evaluará el código con los casos de prueba. 

También se deberá subir el código al [espacio de la actividad en Canvas](https://experiencia21.tec.mx/courses/173572/assignments/4688194). 
Esta actividad forma parte tanto de tu calificación final del curso, así como del portafolio de evidencias de las competencias a desarrollar del curso, por lo que se te pide que :
* Realices una entrega de  los archivos correspondientes a la solución a esta actividad en equipo dentro del espacio de Canvas, que contenga los documentos de reflexión individual (ReflexActInt1.pdf ).
* Generes una carpeta en forma personal INDIVIDUAL llamada TC2038(Portafolio_Final) que servirá como preparación para la entrega del portafolio de competencias que se realizará al final del curso, esta carpeta debe contener 2 carpetas:
  - ActInt1 - coloca aquí tus archivos que solucionaron la actividad integradora 1 así como el documento de reflexión individual (ReflexActInt1.pdf).
  - ActInt2 -

Esta última carpeta es la que subirás al final de la Unidad de Formación en el espacio que se habilitará para tu portafolio de evidencias en eLumen

### ¿Cómo la entrego?
Se tomarán en cuenta las soluciones sometidas en este repositorio de la plataforma de GitHub classroom. Pueden subir su archivo "ActInt1.cpp" por separado o editar el que está arriba y someterlo via *commit*.

Adicionalmente, en el espacio de la tarea en canvas, se debe entregar un archivo .ZIP llamado A0XXXXXXX_ActInt1, (donde las XXXXXXXs son la matrícula de alguno de los integrantes del equipo) que contenga dentro una carpeta llamada A0XXXXXXX_ActInt1, en donde se encontrará UN único archivo .cpp. Se pueden tener uno o más archivos .h.
Incluye un archivo team.txt que incluya los nombres de todos los integrantes del equipo, con sus matrículas y las partes específicas del proyecto en las que trabajó cada quien
Incluye también los 3 archivos ReflexActInt1_A0XXXXXXX.pdf

Por favor respeta el nombre exacto (minúsculas, sin acento) de los archivos de entrada, NO se piden al usuario, van directo en el código fuente
Ten en cuenta que tu programa se probará con archivos grandes.

Se tendrá una sesión de revisión donde a cada integrante del equipo se le harán preguntas específicas y todos deben saber cómo funciona cada parte de la solución propuesta
