#include <iostream>
#include <unordered_map>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

double const PI = M_PI;

struct Point
{
    double r, theta;
    Point(double r_, double theta_)
    {
        r = r_;
        theta = theta_;
    }
    Point(){};
};

void coord_polar(int centro_x, int centro_y, int punto_x, int punto_y, vector<Point> &points)
//x del centro menos x del punto (mismo con y) y en base a esa x y y sacar theta
{
    int x = punto_x - centro_x; //hacer resta
    int y = punto_y - centro_y; //hacer resta
    double theta = atan2(y, x);
    theta = theta * (180 / PI);
    if (theta < 0)
    {
        theta = 360 + theta;
    }
    double r = sqrt(pow(x, 2) + pow(y, 2));
    /*cout << "RRR: " << r << endl;
    cout << "ANTES PUSH" << endl;*/
    Point a(r, theta);
    points.push_back(a);
    //cout << "DESPUES PUSH" << endl;

    //cout << "POINTS SIZE: " << points.size() << endl;
    //return points;
    //return (Point(r, theta));
}

void Shape_context(int centro_x, vector<Point> points)
{
    //cout << "ENTRADA SHAPE" << endl;
    //la distancia entre paso entre los circulos(r del punto que estoy evaluando menos r del centro ) da i y el angulo entre paso de angulos 360 / 12 da j
    int radio = 10;
    int pisos = 5;
    int sectores = 12;
    int division_r = radio / pisos;                                    //dice nivel de r
    int division_theta = 360 / sectores;                               //dice donde esta theta
    vector<vector<int> > matrizFinal(pisos, vector<int>(sectores, 0)); //vector de vectores (matriz) ya empezada en 0

    for (int i = 0; i < points.size(); i++)
    {
        //cout << "I SHAPE: " << i << endl;
        //cout << "points[i].r: " << points[i].r << endl;
        int lugar_r = (int)floor(points[i].r / division_r);
        int lugar_theta = (int)floor(points[i].theta / division_theta);

        //cout << "LUGAR R: " << lugar_r << endl;
        //cout << "LUGAR RTHETA: " << lugar_theta << endl;

        if (points[i].r == 0)
        {
            continue;
        }

        if (points[i].r < radio)
        {
            matrizFinal[lugar_r][lugar_theta]++;
            //cout << "ENTRADA if r < radio" << endl;
        }
    }

    for (int i = 0; i < pisos; i++)
    {
        for (int j = 0; j < sectores; j++)
        {
            cout << matrizFinal[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

void sacar_centro(vector<int> lista_x, vector<int> lista_y, int N) //recibe dos puntos: 1. vector<double> lista_theta, vector<double> lista_r
{
    for (int i = 0; i < N; i++) // si cambiamos el primer valor al final de la lista cambiar a while y crear i=0;
    {
        //cout << "I:" << i << endl;
        vector<Point> points;
        int centro_x = lista_x[i]; //maybe hacer pop a un valor y a ese valor hacer push_back
        int centro_y = lista_y[i]; //por ver:  pasar el primer valor al final de la lista
        for (int j = 0; j < N; j++)
        {
            //cout << "J: " << j << endl;
            if (j == i)
            {
                continue;
            }
            coord_polar(centro_x, centro_y, lista_x[j], lista_y[j], points);
            //cout << "SALIDA DE COORDENADAS POLARES" << endl;
        }
        Shape_context(centro_x, points);
    }
}

int main(int argc, char *argv[])
{
    int N = stoi(argv[1]);

    vector<int> lista_x;
    vector<int> lista_y;

    //convierte coordenadas cartesianas a polares
    for (int i = 0; i < N; i++)
    {
        lista_x.push_back(stoi(argv[i + 2]));
        lista_y.push_back(stoi(argv[i + N + 2]));
    }
    sacar_centro(lista_x, lista_y, N);

    return 0;
}
