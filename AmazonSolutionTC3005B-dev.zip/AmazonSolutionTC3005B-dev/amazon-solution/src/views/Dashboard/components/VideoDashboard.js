function VideoDashboard() {
  return (
    <h1>VIDEO DASHBOARD</h1>
  )
}

export default VideoDashboard
