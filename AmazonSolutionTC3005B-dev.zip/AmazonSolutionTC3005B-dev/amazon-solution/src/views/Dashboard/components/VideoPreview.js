function VideoPreview() {
  return (
    <div className="preview-container">

    </div>
  )
}

export default VideoPreview
