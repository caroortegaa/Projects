function VideoForm() {
  return (
    <h1>This is video form</h1>
  )
}

export default VideoForm
