function Terms() {


    return (
      <h1>Terms</h1>
    )
  }
  
  export default Terms