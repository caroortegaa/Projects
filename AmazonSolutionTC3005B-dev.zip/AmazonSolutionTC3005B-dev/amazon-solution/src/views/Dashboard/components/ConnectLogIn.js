function ConnectLogIn(props) {


  return (
    <div className="connect-login">
      <button className='test' onClick={props.logIn}>Amazon Connect Log In</button>
    </div>
  )
}

export default ConnectLogIn
