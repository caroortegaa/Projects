/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

export { default as Videodashb } from "./Videodashb";
export { default as Popupnewagent } from "./Popupnewagent";
export { default as Component1 } from "./Component1";
export { default as SignUp } from "./SignUp";
export { default as Login } from "./Login";
export { default as Supervisorview } from "./Supervisorview";
export { default as Settings } from "./Settings";
