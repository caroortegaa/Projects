#include <iostream>
#include <unordered_map>
#include <vector>
#include <functional>
#include <queue>
#include <unordered_set>
#include <stack>

using namespace std;

using par_nodos = pair<string, string>;
using conjunto = pair<int, par_nodos>;

class Nodo
{
public:
    string nombre;
    unordered_map<Nodo *, int> siguientes;
    bool visitado;

    Nodo()
    {
        nombre = "";
        visitado = false;
    }

    Nodo(string n)
    {
        nombre = n;
        visitado = false;
    }

    void agregarSiguiente(Nodo *sig, int peso)
    {
        siguientes[sig] = peso;
        //cout<< "HOLA" << siguientes[sig] << endl;
    }

    void imprimirNodo()
    {
        //cout << nombre << ":";
        for (auto sig : siguientes)
        {
            cout << sig.first->nombre << " " << sig.second << " " << endl;
        }
        cout << endl;
    }
};

class Grafo
{
public:
    unordered_map<string, Nodo *> nodos;

    void agregarNodo(string n)
    {
        Nodo *nuevo = new Nodo(n);
        if (nodos.find(n) == nodos.end())
        {
            nodos[n] = nuevo;
        }
    }

    void agregarAdyacencia(string n1, string n2, int peso)
    {
        nodos[n1]->agregarSiguiente(nodos[n2], peso);
    }

    void agregarAdyacenciaNoDirigida(string n1, string n2, int peso)
    {
        nodos[n1]->agregarSiguiente(nodos[n2], peso);
        nodos[n2]->agregarSiguiente(nodos[n1], peso);
        //cout << "peso: " << peso << endl;
    }

    void imprimirGrafo()
    {
        for (auto nodo : nodos)
        {
            //cout << "Nodo first: " << nodo.first << endl;
            nodo.second->imprimirNodo();
        }
    }

    void DFS(string inicial)
    {
        for (auto nodo : nodos)
        {
            nodo.second->visitado = false;
        }
        stack<Nodo *> porProcesar;
        porProcesar.push(nodos[inicial]);
        while (!porProcesar.empty())
        {
            Nodo *nodos_check = porProcesar.top();
            porProcesar.pop();
            for (auto sig : nodos_check->siguientes)
            {
                if (!sig.first->visitado)
                {
                    porProcesar.push(sig.first);
                }
            }
            nodos_check->visitado = true;
        }
        cout << inicial;
        for (auto nodo : nodos)
        {
            if (!nodo.second->visitado)
            {
                cout << " " << nodo.second->nombre;
            }
        }
        cout << endl;
    }

    Grafo MST()
    {
        Grafo g;
        int V = nodos.size();
        unordered_set<string> enlance;
        priority_queue<conjunto, vector<conjunto>, greater<conjunto>> aristas;
        unordered_map<string, string> nodo_padre;
        //unordered_map<pair<nodo, nodo>, int> grafo_final;
        for (auto nodo : nodos)
        {
            for (auto sig : nodo.second->siguientes)
            {
                aristas.push(conjunto(sig.second, par_nodos(nodo.first, sig.first->nombre)));
            }
            nodo_padre[nodo.first] = nodo.first;
        }
        cout << endl;
        while (enlance.size() < V - 1 && !aristas.empty())
        {
            conjunto nodos_check = aristas.top();
            aristas.pop();
            string nodo_principio = nodos_check.second.first; //primer nodo
            string nodo_final = nodos_check.second.second;    //segundo nodo
            if (nodo_principio > nodo_final)
            {
                string temp = nodo_principio;
                nodo_principio = nodo_final;
                nodo_final = temp;
            }
            string x = buscar(nodo_padre, nodo_principio);
            string y = buscar(nodo_padre, nodo_final);
            if (x != y && enlance.find(nodo_principio + nodo_final) == enlance.end())
            {
                /*for (auto par : nodo_padre){
                    cout << " padre.first: " << par.first << " padre.second: " << par.second << endl;

                }
                cout << "NODO PRINCIPIO: " << nodo_principio << endl;
                cout << "NODO FINAL: " << nodo_final << endl;*/
                g.agregarNodo(nodo_principio);
                g.agregarNodo(nodo_final);
                g.agregarAdyacenciaNoDirigida(nodo_principio, nodo_final, nodos_check.first);
                //cout << "PESO MST: " << nodos_check.first << endl;
                unir(nodo_padre, nodo_principio, nodo_final);
                cout << nodo_final << " " << nodo_principio << " " << nodos_check.first << endl;
                for (auto par : nodo_padre)
                {
                    //cout << " padre.first: " << par.first << " padre.second: " << par.second << endl;
                }
                //cout << "NODO PRINCIPIO: " << nodo_principio << endl;
                //cout << "NODO FINAL: " << nodo_final << endl;
                enlance.insert(nodo_principio + nodo_final);
            }
        }
        return g;
    }

    string buscar(unordered_map<string, string> nodo_padre, string buscado)
    {
        if (nodo_padre[buscado] == buscado)
        {
            return buscado;
        }
        return buscar(nodo_padre, nodo_padre[buscado]);
    }

    void unir(unordered_map<string, string> &nodo_padre, string nodo_principio, string nodo_final)
    {
        nodo_padre[nodo_final] = buscar(nodo_padre, nodo_principio);
        nodo_padre[nodo_principio] = buscar(nodo_padre, nodo_final);
    }
};

int main(int argc, char const *argv[])
{
    Grafo g;
    int nodos = stoi(argv[1]);
    //cin >> nodos;
    for (int i = 0; i < nodos; i++)
    {
        g.agregarNodo(to_string(i));
    }

    //int contador = 2;
    for (int i = 0; i < nodos; i++)
    {
        int siguiente = stoi(argv[i + 2 + nodos * 2]);
        //cin >> siguiente;
        //siguiente= stoi(argv[contador]);
        //contador++;
        if (siguiente != 0)
        {
            //cout << "Siguiente: " << siguiente << endl;
            g.agregarAdyacenciaNoDirigida(to_string(stoi(argv[i + 2])), to_string(stoi(argv[i + 2 + nodos])), siguiente);
        }
        /*for (int j = 0; j < nodos; j++)
        {
            int siguiente = stoi(argv[i + 2]);
            //cin >> siguiente;
            //siguiente= stoi(argv[contador]);
            //contador++;
            if (siguiente != 0)
            {
                cout << "Siguiente: " << siguiente << endl;
                g.agregarAdyacenciaNoDirigida(to_string(i), to_string(j), siguiente);
            }
        }*/
    }

    g.imprimirGrafo();
    Grafo minimo = g.MST();
    cout << "Grafo minimo:" << endl;
    minimo.imprimirGrafo();
    return 0;
}
