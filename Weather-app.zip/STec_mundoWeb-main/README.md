# STec_mundoWeb
## Carolina Ortega A01025254
Semana Tec: Conectando al mundo web

En esta Semana Tec se desarrollo un proyecto de una aplicación "Weather" en la que el diseño fue libre para cada alumno, requiriendo que se mostrara la información de ciudades del mundo y su clima.

## Imagen de la vista final de la Weather App
<img width="866" alt="Screen Shot 2021-10-29 at 23 02 20" src="https://user-images.githubusercontent.com/57368415/139519550-af4bdf77-5c7d-4e4d-bd3d-b00f4fedfbac.png">

