const check = function () {
    console.log('Desarrollando sin presión...')
}

module.exports = check