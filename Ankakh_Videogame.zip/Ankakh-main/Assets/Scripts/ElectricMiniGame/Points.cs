﻿/*using UnityEngine;
using UnityEngine.UI;

public class Points : MonoBehaviour
{
    // Variables visible from Unity
    [SerializeField] Text textScore;
    [SerializeField] WireConnection Done ;

    // Made score public so that it could be accessed from the wwwFormGameData script
    public int score = 0;

    void Done(GameObject lightOn)
    {
        score++;
        
        textScore.text = "Score: " + score;
    }

   
}*/
