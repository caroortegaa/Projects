#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Point
{
    int x, y;
    Point(int x_, int y_)
    {
        x = x_;
        y = y_;
    }
    Point(){};
};

int orientation(Point p, Point q, Point r) //p= centro (penultimo valor), q= vector a (antepenultimo valor), r= vector b ultimo valor
{
    int val = (q.y - p.y) * (r.x - p.x) - (q.x - p.x) * (r.y - p.y);

    return val;
}

void convexHull(vector<Point> points, int n)
{

    if (n < 3)
        return;

    vector<Point> respuestas;

    respuestas.push_back(points[0]);
    respuestas.push_back(points[1]);

    for (int i = 2; i < n; i++)
    {
        respuestas.push_back(points[i]);
        while ((respuestas.size() > 2) && orientation(respuestas[respuestas.size() - 2], respuestas[respuestas.size() - 1], respuestas[respuestas.size() - 3]) <= 0)
        {
            respuestas.erase(respuestas.end() - 2);
        }
    }
    respuestas.push_back(points[n - 2]); //agregamos el penultimo punto
    for (int i = n - 3; i > 0; i--)
    {
        respuestas.push_back(points[i]);
        while ((respuestas.size() > 2) && orientation(respuestas[respuestas.size() - 2], respuestas[respuestas.size() - 1], respuestas[respuestas.size() - 3]) <= 0)
        {
            respuestas.erase(respuestas.end() - 2);
        }
    }

    for (int i = 0; i < respuestas.size(); i++)
    {
        cout << respuestas[i].x << " " << respuestas[i].y << endl;
    }
}
int compareByX(Point &a, Point &b)
{
    return a.x < b.x;
}
int main(int argc, char *argv[])
{
    int N = stoi(argv[1]);
    vector<Point> points;
    for (int i = 2; i < N + 2; i++)
    { 
        points.push_back(Point(stoi(argv[i]), stoi(argv[i + N])));
    }

    sort(points.begin(), points.end(), compareByX);
    convexHull(points, N);
    return 0;
}
