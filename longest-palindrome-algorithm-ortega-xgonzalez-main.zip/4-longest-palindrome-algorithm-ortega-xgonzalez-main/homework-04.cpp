#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <fstream>
#include <vector>


using namespace std;
int min(int num1, int num2)
{
    int result;
    if (num1 > num2)
    {
        result = num2;
    }
    else
    {
        result = num1;
    }

    return result;
}
void palindromo(string palabra)
{
    int l = palabra.length();
    int c = 0; //centro de la palabra
    int d = 0; //limite de la derecha
    vector<int> tamano(l, 0);
    //cout << "palindromo" << endl;

    for (int i = 1; i <= l - 1; i++)
    {
        int mirror = 2 * c - i;
        //cout << "MIRROR: " << mirror << endl;

        if (i < d)
        {
            //cout << "D1: " << d << endl;
            tamano[i] = min(d - i, tamano[mirror]);
            //cout << "TAMAÑO[I] if 1: " << tamano[i] << endl;
        }
        /*else
        {
            tamano[i] = 0;
            //cout << "TAMAÑO[I] else 1: " << tamano[i] << endl;
        }*/

        int a = palabra[i + (1 + tamano[i])]; // a= # palabra 14
        //cout << "A: " << a << endl;
        int b = palabra[i - (1 + tamano[i])]; //b= # palabra 12
        //cout << "B: " << b << endl;

        int j = 0;
        while (a == b)
        {
            tamano[i]++;
            a = palabra[i + (1 + tamano[i])]; // a= 15
            b = palabra[i - (1 + tamano[i])]; // b=11
            /* cout << "IGUALES: " << endl;
            cout << "A: " << a << endl;
            cout << "B: " << b << endl;*/
        }

        if (i + tamano[i] > d)
        {
            /*cout << "I: " << i << endl;
            cout << "C: " << c << "  ";
            cout << "D: " << d << "  ";
            cout << "t[i]: " << tamano[i] << endl;*/
            c = i;
            d = i + tamano[i];
            //cout << "IF " << tamano[i] << endl;
        }
    }
    for (int i = 0; i < tamano.size(); i++)
    {
        cout << "i: " << i << endl;
        cout << tamano[i] << "--> " << palabra[i] << endl;
    }
    //return c;
    int valor_max = *max_element(tamano.begin(), tamano.end());
    //cout << "VALOR MAX: " << valor_max << endl;
    vector<int>::iterator indice = find(tamano.begin(), tamano.end(), valor_max);
    //cout << "indice: " << indice << endl;
    int resultado = ((indice - tamano.begin()) - valor_max) / 2; //RES -1?  
    cout << resultado << " " << valor_max << endl;
}

int main(int argc, char *argv[])
{
    string palabra = argv[1];
    palabra.erase(std::remove(palabra.begin(), palabra.end(), ' '), palabra.end());
    for (int i = 0; i < palabra.length(); i++)
    {
        palabra[i] = tolower(palabra[i]);
    }
    string palabra_nueva;
    cout << palabra_nueva << endl;
    int j = 0;
    for (int i = 0; i < palabra.length() * 2 + 1; i++)
    {
        if (i % 2 == 0)
        {
            palabra_nueva.push_back('#');
        }
        if (i % 2 != 0)
        {
            palabra_nueva.push_back(palabra[j]);
            j++;
        }
    }
    //cout << palabra_nueva << endl;
    palindromo(palabra_nueva);
}
