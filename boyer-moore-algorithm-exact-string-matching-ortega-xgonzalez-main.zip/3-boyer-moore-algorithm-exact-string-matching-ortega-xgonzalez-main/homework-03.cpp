//Carolina Ortega A01025254
//Ximena Gonzalez A01028604

#include <iostream>
#include <vector>
#include <array>
#include <algorithm>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <string>

using namespace std;

int bad_character(string cadena, string palabra, int l, int salto, int i)
{
    salto = 0;

    for (int j = i - 1; j <= palabra.size() && j != -1; j--)
    {
        if (cadena[l] == palabra[j])
        {
            salto = palabra.length() - (j + 1);
            break;
        }
    }
    if (salto == 0)
    {

        salto = palabra.length();
    }
    return salto;
}

int good_shift(string cadena, string palabra, int l, int contador_match, int salto, string gs_word, int i)
{
    reverse(gs_word.begin(), gs_word.end());
    vector<int> indices_match;
    int w = 0;
    int w2 = 0;
    salto = 0;
    i += 1;
    while (w < palabra.length() - gs_word.length())
    {

        if (palabra[w] == gs_word[w2])
        {
            indices_match.push_back(w);
            w++;
            w2++;
        }

        else
        {
            w++;
        }

        if (indices_match.empty())
        {
            salto = palabra.length();
        }

        else
        {
            salto = i + indices_match[0];
        }
    }

    return salto;
}

int max(int num1, int num2)
{
    int result;
    if (num1 > num2)
    {
        result = num1;
    }
    else
    {
        result = num2;
    }

    return result;
}

int main(int argc, char *argv[])
{
    vector<int> indices;
    string cadena = argv[1];
    string palabra = argv[2];

    cout << "cadena: " << cadena << endl;
    cout << "palabra: " << palabra << endl;

    int l = palabra.size() - 1; //longitud // quite - 1
    int i = palabra.size() - 1;
    int salto;
    int salto_bad;
    int salto_good;
    string gs_word;
    int contador_l = 0;
    int contador_match = 0;

    while (l < cadena.length() || l == -1)
    {
        if (i == -1)
        {
            l += palabra.length();
        }
        if (cadena[l] == palabra[i])
        {
            gs_word += palabra[i];
            contador_match++;
            contador_l++;
            l--;
            i--;
        }

        else
        {

            if (contador_match == 0 || contador_match == 1) //|| cadena[l] == ' '
            {
                salto_bad = bad_character(cadena, palabra, l, salto, i);
            }
            else
            {
                salto_bad = bad_character(cadena, palabra, l, salto, i);
                //salto_good = good_shift(cadena, palabra, l, contador_match, salto, gs_word, i);
            }

            contador_match = 0;
            gs_word.clear();

            int resultado = max(salto_bad, salto_good);
            //cout << "resultado: " << resultado << endl;
            l += resultado + contador_l;
            i = palabra.length() - 1;
            contador_match++;
            contador_l = 0;
        }

        if (contador_match == palabra.length()) // quite - 1
        {
            indices.push_back(l);
        }

        sort(indices.begin(), indices.end());
    }

    if (indices.size() == 0)
    {
        cout << "arreglo de indces vacio" << endl;
    }

    for (int i = 0; i < indices.size(); i++)
    {
        cout << indices[i] << " ";
    }
}
